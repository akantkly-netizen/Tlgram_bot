'use strict';
// ================= پشت‌صحنهٔ زنده (تم‌های آب‌وهوایی) =================
let bgP=[],curTh=0,lightT=3,lightFlash=0,metT=1,twks=[],wins=[],bolt=null,bgPulse=0;
function pulseBG(){bgPulse=1;}
function newBGP(any){const th=curTh;
 if(th===1)return{x:rnd(0,W),y:any?rnd(0,H):-20,vy:rnd(H*.9,H*1.5),vx:W*.035,l:rnd(12,26),a:rnd(.12,.4)};
 if(th===2)return{x:rnd(0,W),y:any?rnd(0,H):-8,vy:rnd(28,70),vx:0,r:rnd(1.4,3.4),a:rnd(.45,.95),ph:rnd(0,TAU)};
 if(th===3)return{x:rnd(0,W),y:any?rnd(0,H):-20,vy:rnd(H*.8,H*1.3),vx:W*.055,l:rnd(10,22),a:rnd(.1,.32)};
 if(th===4){const cols=['#ff2bd6','#ffd166','#7ef3ff','#b388ff'];
  return{x:rnd(0,W),y:any?rnd(0,H):-14,vy:rnd(34,80),vx:rnd(-16,16),r:rnd(2.5,5),a:rnd(.5,.95),rot:rnd(0,TAU),vr:rnd(-2.4,2.4),c:cols[Math.floor(Math.random()*4)]};}
 if(th===5){if(Math.random()<.35)return{x:rnd(0,W),y:any?rnd(0,H):H+10,vy:-rnd(20,60),vx:rnd(-8,8),r:rnd(1,2.6),a:rnd(.3,.8),c:Math.random()<.5?'#ffb020':'#ff6b3d'};
  return{x:rnd(0,W*.9),y:any?rnd(-H*.5,0):-rnd(20,120),vy:rnd(H*1.3,H*2),vx:W*.42,l:rnd(26,52),a:rnd(.5,.95),c:'#ffe08a'};}
 return{x:rnd(0,W),y:any?rnd(0,H):H+10,vy:-rnd(8,26),vx:rnd(-4,4),r:rnd(1,2.8),a:rnd(.15,.5)};}
function buildBG(){const th=THEMES[curTh];
 bgCache=document.createElement('canvas');bgCache.width=Math.max(2,W);bgCache.height=Math.max(2,H);
 const g=bgCache.getContext('2d');
 const gr=g.createLinearGradient(0,0,0,H);gr.addColorStop(0,th.sky[0]);gr.addColorStop(.55,th.sky[1]);gr.addColorStop(1,th.sky[2]);
 g.fillStyle=gr;g.fillRect(0,0,W,H);
 for(let i=0;i<3;i++){const nx=W*(.22+.28*i),ny=H*(.1+.15*i),nr=Math.min(W,H)*(.45+.18*i);
  const ng=g.createRadialGradient(nx,ny,0,nx,ny,nr);ng.addColorStop(0,'rgba('+th.glow+',.11)');ng.addColorStop(1,'rgba('+th.glow+',0)');
  g.fillStyle=ng;g.fillRect(0,0,W,H);}
 for(let i=0;i<150;i++){g.globalAlpha=rnd(.15,.85);g.fillStyle=Math.random()<.85?'#cfeaff':th.tint;
  g.fillRect(rnd(0,W),rnd(0,horizonY*1.02),rnd(1,2.4),rnd(1,2.4));}
 g.globalAlpha=1;
 const sr=Math.min(W,H)*.19,sx=W*.5,sy=horizonY-sr*.22;
 g.save();g.beginPath();g.arc(sx,sy,sr,0,TAU);
 const sg=g.createLinearGradient(0,sy-sr,0,sy+sr);sg.addColorStop(0,th.tint);sg.addColorStop(1,'rgba('+th.glow+',.3)');
 g.fillStyle=sg;g.fill();g.clip();
 if(th.sunT==='sun'){g.fillStyle=th.sky[1];for(let y=sy-sr*.1;y<sy+sr;y+=sr*.17)g.fillRect(sx-sr,y,sr*2,sr*.06);}
 else{g.fillStyle='rgba(10,16,40,.4)';
  g.beginPath();g.arc(sx-sr*.34,sy-sr*.28,sr*.2,0,TAU);g.fill();
  g.beginPath();g.arc(sx+sr*.28,sy+sr*.16,sr*.14,0,TAU);g.fill();}
 g.restore();
 g.save();g.shadowColor=th.tint;g.shadowBlur=34;g.strokeStyle='rgba('+th.glow+',.55)';g.lineWidth=2;
 g.beginPath();g.arc(sx,sy,sr,0,TAU);g.stroke();g.restore();
 wins=[];
 const bld=(yBase,hMax,col,alpha,win)=>{let x=-10;
  while(x<W+10){const bw=rnd(W*.05,W*.12),bh=rnd(hMax*.35,hMax);
   g.globalAlpha=alpha;g.fillStyle=col;g.fillRect(x,yBase-bh,bw,bh);g.globalAlpha=1;
   if(win)for(let wx=x+4;wx<x+bw-4;wx+=9)for(let wy=yBase-bh+6;wy<yBase-8;wy+=12)
    if(Math.random()<.3){g.fillStyle='rgba('+th.glow+',.8)';g.fillRect(wx,wy,3,5);
     if(Math.random()<.1)wins.push({x:wx,y:wy,ph:rnd(0,TAU)});}
   x+=bw+rnd(4,18);}};
 bld(horizonY+6,H*.15,th.sky[0],.9,false);
 bld(horizonY+10,H*.11,'#02040c',.96,true);
 const hz=g.createLinearGradient(0,horizonY-70,0,horizonY+90);
 hz.addColorStop(0,'rgba('+th.glow+',0)');hz.addColorStop(.5,'rgba('+th.glow+',.2)');hz.addColorStop(1,'rgba('+th.glow+',0)');
 g.fillStyle=hz;g.fillRect(0,horizonY-70,W,160);
 g.strokeStyle='rgba('+th.grid+',.16)';g.lineWidth=1;
 for(let i=-14;i<=14;i++){g.beginPath();g.moveTo(W/2+i*W*.06,horizonY);g.lineTo(W/2+i*W*.5,H);g.stroke();}
 for(let y=horizonY+18,step=10;y<H+60;y+=step,step*=1.42){g.globalAlpha=clamp((y-horizonY)/(H-horizonY),0,1)*.5;
  g.beginPath();g.moveTo(0,y);g.lineTo(W,y);g.stroke();}
 g.globalAlpha=1;
 const vg=g.createRadialGradient(W/2,H*.45,Math.min(W,H)*.45,W/2,H*.55,Math.max(W,H)*.85);
 vg.addColorStop(0,'rgba(0,0,0,0)');vg.addColorStop(1,'rgba(0,0,0,.5)');
 g.fillStyle=vg;g.fillRect(0,0,W,H);
 twks=[];for(let i=0;i<26;i++)twks.push({x:rnd(0,W),y:rnd(0,horizonY*.92),r:rnd(.8,1.9),ph:rnd(0,TAU),sp:rnd(1.5,4)});}
function initBGFX(th){curTh=((th%THEMES.length)+THEMES.length)%THEMES.length;buildBG();bgP=[];
 lightT=rnd(2.5,5);lightFlash=0;metT=.6;bolt=null;
 const n=curTh===1?90:curTh===2?70:curTh===3?130:curTh===4?44:curTh===5?30:46;
 for(let i=0;i<n;i++)bgP.push(newBGP(true));}
function updBGFx(dt){bgPulse=Math.max(0,bgPulse-dt*2.6);const th=curTh;
 if(th===3){lightT-=dt;if(lightT<=0){lightFlash=1;lightT=rnd(3.5,7);
  bolt={pts:[]};let bx=rnd(W*.15,W*.85),by=0;
  for(let s=0;s<8;s++){bolt.pts.push({x:bx,y:by});by+=horizonY/8+rnd(-10,10);bx+=rnd(-W*.05,W*.05);}
  bolt.pts.push({x:bx,y:horizonY});}
  lightFlash=Math.max(0,lightFlash-dt*2.6);}
 if(th===5){metT-=dt;if(metT<=0){metT=rnd(.5,1.6);bgP.push(newBGP(false));
  if(bgP.length>64)bgP.splice(0,bgP.length-64);}}
 for(const p of bgP){p.x+=p.vx*dt;p.y+=p.vy*dt;
  if(th===2)p.x+=Math.sin(p.y*.02+(p.ph||0))*18*dt;
  if(th===4)p.rot+=p.vr*dt;
  if(p.vy>0&&p.y>H+40)Object.assign(p,newBGP(false));
  else if(p.vy<0&&(p.y<-40||p.y<-p.l))Object.assign(p,newBGP(false));}}
function drawTwks(t){for(const s of twks){
  ctx.globalAlpha=.2+.55*(.5+.5*Math.sin(t*s.sp+s.ph));
  ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(s.x,s.y,s.r,0,TAU);ctx.fill();}
 ctx.globalAlpha=1;}
function drawRibbons(t){const th=THEMES[curTh];ctx.save();ctx.globalCompositeOperation='lighter';
 for(let i=0;i<3;i++){const yBase=H*(.13+.09*i);ctx.beginPath();
  for(let x=0;x<=W+W/14;x+=W/14){const y=yBase+Math.sin(x*4/W+t*(.35+.13*i)+i*2.1)*H*.045;
   x?ctx.lineTo(x,y):ctx.moveTo(x,y);}
  ctx.strokeStyle='rgba('+(i===1?'255,120,220':th.glow)+','+(0.05+.03*Math.sin(t*.8+i*1.7)+bgPulse*.05).toFixed(3)+')';
  ctx.lineWidth=H*.045+i*H*.014;ctx.stroke();}
 ctx.restore();}
function drawBGFx(t){const th=curTh;
 ctx.save();
 for(const p of bgP){ctx.globalAlpha=p.a;
  if(th===1||th===3){ctx.strokeStyle=th===1?'#8fd8ff':'#c4d6ff';ctx.lineWidth=th===1?1.4:1.8;
   ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(p.x-p.vx*.05,p.y-p.l);ctx.stroke();}
  else if(th===2){ctx.fillStyle='#eaf6ff';ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,TAU);ctx.fill();}
  else if(th===4){ctx.save();ctx.translate(p.x,p.y);ctx.rotate(p.rot);ctx.fillStyle=p.c;
   ctx.beginPath();ctx.ellipse(0,0,p.r,p.r*.55,0,0,TAU);ctx.fill();ctx.restore();}
  else if(th===5){if(p.vy>0){ctx.strokeStyle=p.c;ctx.lineWidth=1.6;
    ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(p.x-p.vx*.05,p.y-p.l);ctx.stroke();}
   else{ctx.fillStyle=p.c;ctx.shadowColor=p.c;ctx.shadowBlur=6;
    ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,TAU);ctx.fill();ctx.shadowBlur=0;}}
  else{ctx.fillStyle='#9fdcff';ctx.shadowColor='#00e5ff';ctx.shadowBlur=6;
   ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,TAU);ctx.fill();ctx.shadowBlur=0;}}
 ctx.restore();ctx.globalAlpha=1;
 for(const w of wins)if(Math.sin(t*2.4+w.ph)>.88){ctx.fillStyle='rgba('+th.glow+',.9)';ctx.fillRect(w.x,w.y,3,5);}
 if(lightFlash>0){ctx.fillStyle='rgba(205,218,255,'+(lightFlash*.3).toFixed(3)+')';ctx.fillRect(0,0,W,H);
  if(bolt){ctx.save();ctx.globalAlpha=Math.min(1,lightFlash*1.4);ctx.strokeStyle='#e6e0ff';ctx.lineWidth=2.5;
   ctx.shadowColor='#9d8bff';ctx.shadowBlur=18;ctx.beginPath();
   bolt.pts.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.stroke();ctx.restore();}}
 else bolt=null;}
