'use strict';
// ================= صداهای آماده — همهٔ فایل‌ها داخل پوشهٔ audio/ (بازی کامل آفلاین) =================
// فقط اگر فایل محلی نبود، از CDN اینترنتی به‌عنوان پشتیبان استفاده می‌شود
// نسخهٔ ۲.۲: صدای تشویق و سکه حذف شدند (درخواست کاربر) — فقط شلیک/انفجار/موج/رابط/پاپ
const SFX={
 shoot:'audio/shoot.mp3',
 boom:'audio/boom.mp3',
 wave:'audio/wave.ogg',
 ui:'audio/ui.ogg',
 pop:'audio/pop.ogg'
};
const SFX_CDN={
 shoot:'https://assets.mixkit.co/active_storage/sfx/1662/1662-preview.mp3',
 boom:'https://assets.mixkit.co/active_storage/sfx/1690/1690-preview.mp3',
 wave:'https://actions.google.com/sounds/v1/alarms/digital_watch_alarm_long.ogg',
 ui:'https://actions.google.com/sounds/v1/alarms/beep_short.ogg',
 pop:'https://actions.google.com/sounds/v1/cartoon/pop.ogg'
};
// پیانوی آماده (Salamander Grand, CC-BY) — هر کاشی با نرخ پخش درست، نت واقعی می‌نوازد
const PIANO_LOCAL={54:'audio/piano_Fs3.mp3',60:'audio/piano_C4.mp3',69:'audio/piano_A4.mp3',78:'audio/piano_Fs5.mp3',84:'audio/piano_C6.mp3'};
const PIANO_CDN={54:'https://tonejs.github.io/audio/salamander/Fs3.mp3',60:'https://tonejs.github.io/audio/salamander/C4.mp3',69:'https://tonejs.github.io/audio/salamander/A4.mp3',78:'https://tonejs.github.io/audio/salamander/Fs5.mp3',84:'https://tonejs.github.io/audio/salamander/C6.mp3'};
const MUSIC_LOCAL='audio/music.mp3';
const MUSIC_CDN='https://incompetech.com/music/royalty-free/mp3-royaltyfree/Electrodoodle.mp3';

let muted=false;
try{muted=localStorage.getItem('ns_mute')==='1'}catch(e){}

// --- تنظیمات صدا (پنل «تنظیمات صدا» در منو) — نسخهٔ ۲.۲ ---
// music=موزیک منو، shot=صدای تیر (پیش‌فرض کم شد)، piano=نت‌های پیانو، sfx=جلوه‌ها
const VOL={music:.3,shot:.09,piano:.95,sfx:.5};
try{const v=JSON.parse(localStorage.getItem('ns_vol')||'null');
 if(v){['music','shot','piano','sfx'].forEach(k=>{if(typeof v[k]==='number'&&v[k]>=0&&v[k]<=1)VOL[k]=v[k];});}}catch(e){}
function saveVols(){try{localStorage.setItem('ns_vol',JSON.stringify(VOL))}catch(e){}}

// --- WebAudio ---
let AC=null,master=null;const WA={},PIANO={};
let loadN=0,loadTotal=0,waJob=false;
function ensureAC(){try{
 if(!AC){AC=new(window.AudioContext||window.webkitAudioContext)();
  master=AC.createGain();master.gain.value=.9;
  const cp=AC.createDynamicsCompressor();master.connect(cp);cp.connect(AC.destination);}
 if(AC&&AC.state==='suspended')AC.resume();}catch(e){}}

// دریافت بایت‌های صدا: اول fetch، بعد XHR (برای file:// در اندروید)
function getBytes(url){return new Promise(res=>{
 let done=false;const fin=v=>{if(!done){done=true;res(v||null);}};
 try{fetch(url,{mode:'cors'}).then(r=>{
   if(!r.ok)return fin(null);return r.arrayBuffer().then(ab=>fin(ab));}).catch(()=>xhr());}
 catch(e){xhr();}
 function xhr(){try{
   const x=new XMLHttpRequest();x.open('GET',url);x.responseType='arraybuffer';
   x.onload=()=>{try{fin((x.status===200||x.status===0)&&x.response?x.response:null);}catch(e){fin(null);}};
   x.onerror=()=>fin(null);x.onabort=()=>fin(null);
   x.send();}catch(e){fin(null);}}});}
async function decode(url,dst,key){
 const ab=await getBytes(url);if(!ab)return false;
 try{dst[key]=await AC.decodeAudioData(ab);return true;}catch(e){return false;}}

async function loadAll(prog){
 ensureAC();if(!AC)return;
 if(waJob){if(prog)prog(loadN,Math.max(1,loadTotal));return;}
 waJob=true;
 const jobs=[];
 for(const k in SFX)jobs.push(['WA',k]);
 for(const k in PIANO_LOCAL)jobs.push(['PIANO',k]);
 loadTotal=jobs.length;loadN=0;
 for(const[dst,key]of jobs){
  const D=dst==='WA'?WA:PIANO;
  if(!D[key]){
   const local=dst==='WA'?SFX[key]:PIANO_LOCAL[key];
   const cdn=dst==='WA'?SFX_CDN[key]:PIANO_CDN[key];
   const ok=await decode(local,D,key);
   if(!ok)await decode(cdn,D,key);}
  loadN++;if(prog)prog(loadN,loadTotal);}
 setTimeout(retryMissing,15000);}
function retryMissing(){if(!AC)return;
 (async()=>{
  for(const k in SFX)if(!WA[k])await decode(SFX[k],WA,k)||await decode(SFX_CDN[k],WA,k);
  for(const k in PIANO_LOCAL)if(!PIANO[k])await decode(PIANO_LOCAL[k],PIANO,k)||await decode(PIANO_CDN[k],PIANO,k);})();
 setTimeout(retryMissing,15000);}
function waPlay(k,rate,vol){if(!AC||!WA[k])return false;
 try{const s=AC.createBufferSource();s.buffer=WA[k];s.playbackRate.value=rate||1;
  const g=AC.createGain();g.gain.value=vol;s.connect(g);g.connect(master);s.start();return true;}catch(e){return false;}}
class Pool{
 constructor(key,n,vol){this.key=key;this.vol=vol;this.i=0;this.list=[];
  for(let q=0;q<n;q++){const a=new Audio();a.preload='auto';a.src=SFX[key];a.volume=vol;
   a.addEventListener('error',()=>{if(a.src.indexOf('http')!==0)a.src=SFX_CDN[key];},{once:true});
   this.list.push(a);}}
 play(rate){if(muted)return;
  if(waPlay(this.key,rate,this.vol))return;
  const a=this.list[this.i=(this.i+1)%this.list.length];
  try{a.playbackRate=rate||1;a.currentTime=0;const p=a.play();if(p&&p.catch)p.catch(()=>{});}catch(e){}}
 setVol(v){this.vol=v;for(const a of this.list)a.volume=v;}
}
// اعمال ولوم‌های تنظیمات روی همهٔ صداها
function applyVols(){if(music)music.volume=Math.min(1,VOL.music);
 if(snd.shoot)snd.shoot.setVol(VOL.shot);
 if(snd.boom)snd.boom.setVol(VOL.sfx);
 if(snd.wave)snd.wave.setVol(VOL.sfx);
 if(snd.ui)snd.ui.setVol(VOL.sfx*.7);
 if(snd.pop)snd.pop.setVol(VOL.sfx*.36);}
// ترکیب صدا: تفنگ خیلی کم‌تر (درخواست ۲.۲) — پیانوی نت‌ها بلند و شفاف
const snd={
 shoot:new Pool('shoot',6,VOL.shot),
 boom:new Pool('boom',3,VOL.sfx),
 wave:new Pool('wave',2,VOL.sfx),
 ui:new Pool('ui',2,VOL.sfx*.7),
 pop:new Pool('pop',3,VOL.sfx*.36)
};
function playNote(midi,vol){if(muted||!AC)return;
 let base=54,bd=1e9;
 for(const k in PIANO){const d=Math.abs(midi-+k);if(d<bd){bd=d;base=+k;}}
 if(!PIANO[base])return;
 try{const s=AC.createBufferSource();s.buffer=PIANO[base];
  s.playbackRate.value=Math.pow(2,(midi-base)/12);
  const g=AC.createGain();const t0=AC.currentTime;
  g.gain.setValueAtTime(0,t0);g.gain.linearRampToValueAtTime(vol==null?VOL.piano:vol,t0+.004);
  s.connect(g);g.connect(master);s.start(t0);s.stop(t0+3);}catch(e){}}
// --- موزیک منو (فایل محلی) — فقط در منو پخش می‌شود (درخواست ۲.۲) ---
const music=new Audio();music.preload='auto';music.loop=true;music.volume=Math.min(1,VOL.music);
music.addEventListener('error',()=>{if(music.src.indexOf('http')!==0){music.src=MUSIC_CDN;const p=music.play();if(p&&p.catch)p.catch(()=>{});}},true);
music.src=MUSIC_LOCAL;
// گارد: موزیک فقط وقتی پخش می‌شود که در منو هستیم — وسط بازی هیچ handler آن را روشن نمی‌کند
function resumeMusic(){if(typeof state!=='undefined'&&state!=='menu')return;
 if(!muted&&music.paused){const p=music.play();if(p&&p.catch)p.catch(()=>{});}}
function pauseMusic(){music.pause();}
function setMute(m){muted=m;try{localStorage.setItem('ns_mute',m?'1':'0')}catch(e){}
 $('muteBtn').textContent='صدا: '+(m?'خاموش':'روشن');
 if(m)music.pause();else resumeMusic();}
applyVols();
