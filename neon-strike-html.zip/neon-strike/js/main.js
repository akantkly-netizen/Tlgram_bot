'use strict';
// ================= render =================
function drawTracers(){ctx.globalCompositeOperation='lighter';
 for(const tr of tracers){ctx.globalAlpha=clamp(tr.life/.06,0,1)*.85;
  ctx.strokeStyle='#bfe9ff';ctx.lineWidth=2;
  ctx.beginPath();ctx.moveTo(tr.x1,tr.y1);ctx.lineTo(tr.x2,tr.y2);ctx.stroke();}
 ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';}
function drawParts(){for(const p of parts){const a=clamp(p.life/p.ml,0,1);
 if(p.ring){ctx.globalAlpha=a;ctx.strokeStyle=p.c;ctx.lineWidth=3*a+1;
  ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,TAU);ctx.stroke();}
 else if(p.flash){ctx.globalCompositeOperation='lighter';ctx.globalAlpha=a*.9;
  const g=ctx.createRadialGradient(p.x,p.y,0,p.x,p.y,p.r*2);
  g.addColorStop(0,'rgba(255,255,255,.95)');g.addColorStop(1,'rgba(255,255,255,0)');
  ctx.fillStyle=g;ctx.beginPath();ctx.arc(p.x,p.y,p.r*2,0,TAU);ctx.fill();
  ctx.globalCompositeOperation='source-over';}
 else if(p.note){ctx.save();ctx.globalAlpha=a*.95;ctx.translate(p.x,p.y);ctx.rotate(p.rot||0);
  ctx.drawImage(NOTE_SPR,-p.sz*.55,-p.sz*.55,p.sz*1.1,p.sz*1.1);ctx.restore();}
 else{ctx.globalAlpha=a;ctx.fillStyle=p.c;ctx.fillRect(p.x-p.sz/2,p.y-p.sz/2,p.sz,p.sz);}}
 ctx.globalAlpha=1;}
function drawTexts(){ctx.textAlign='center';
 for(const t of texts){ctx.globalAlpha=clamp(t.life/t.ml,0,1);
  ctx.font='800 '+t.size+'px Vazirmatn,Tahoma';ctx.fillStyle=t.c;
  ctx.shadowColor=t.c;ctx.shadowBlur=10;ctx.fillText(t.str,t.x,t.y);ctx.shadowBlur=0;}
 ctx.globalAlpha=1;}
function drawGun(t){const ang=gunAng-recoil*.09;
 const c=Math.cos(ang),s=Math.sin(ang);
 const ox=-c*recoil*22,oy=-s*recoil*22;
 ctx.save();ctx.translate(gunX,gunY);ctx.rotate(ang);ctx.translate(ox,oy);
 ctx.drawImage(GUN,-100,-90);ctx.restore();
 mzX=gunX+ox+c*396-s*(-6);mzY=gunY+oy+s*396+c*(-6);
 if(flashT>0){ctx.save();ctx.translate(mzX,mzY);ctx.rotate(rnd(0,TAU));
  ctx.globalCompositeOperation='lighter';
  const g=ctx.createRadialGradient(0,0,0,0,0,90);
  g.addColorStop(0,'rgba(255,255,240,.95)');g.addColorStop(.35,'rgba(255,209,102,.55)');g.addColorStop(1,'rgba(255,120,0,0)');
  ctx.fillStyle=g;ctx.beginPath();ctx.arc(0,0,90,0,TAU);ctx.fill();
  ctx.fillStyle='rgba(255,255,230,.9)';
  ctx.beginPath();ctx.moveTo(0,-7);ctx.lineTo(46,0);ctx.lineTo(0,7);ctx.closePath();ctx.fill();
  ctx.beginPath();ctx.arc(0,0,12,0,TAU);ctx.fill();
  ctx.restore();}}
function drawCross(){const gap=8+spread*20,L=10;
 const col=overTile?'#ff3b5c':'#eaffff';
 ctx.strokeStyle=col;ctx.lineWidth=2;ctx.shadowColor=col;ctx.shadowBlur=6;
 ctx.beginPath();
 ctx.moveTo(aimX-gap-L,aimY);ctx.lineTo(aimX-gap,aimY);
 ctx.moveTo(aimX+gap,aimY);ctx.lineTo(aimX+gap+L,aimY);
 ctx.moveTo(aimX,aimY-gap-L);ctx.lineTo(aimX,aimY-gap);
 ctx.moveTo(aimX,aimY+gap);ctx.lineTo(aimX,aimY+gap+L);
 ctx.stroke();
 ctx.fillStyle=col;ctx.beginPath();ctx.arc(aimX,aimY,2,0,TAU);ctx.fill();ctx.shadowBlur=0;}
function drawTilesAll(t){const hy=killLine(),hor=horizonY,laneW=W/4,R=camR(),vpx=W/2;
 const xAt=(flat,s)=>vpx+(flat-vpx)*s;
 // سطح تیرهٔ جاده تا خط خطر — جداسازی مسیر از پس‌زمینه
 ctx.fillStyle='rgba(3,10,24,.52)';
 ctx.beginPath();ctx.moveTo(vpx-vpx/R,hor);ctx.lineTo(vpx+vpx/R,hor);
 ctx.lineTo(W,hy);ctx.lineTo(0,hy);ctx.closePath();ctx.fill();
 // ستون‌های نور لاین — تنفس زندهٔ مسیر + برخاست با ضربه (نسخهٔ ۲.۲)
 for(let i=0;i<4;i++){const a=.028+.03*Math.sin(t*.9+i*1.7)+bgPulse*.16;
  const g=ctx.createLinearGradient(0,hor,0,hy);
  g.addColorStop(0,'rgba(0,229,255,0)');g.addColorStop(1,'rgba(0,229,255,'+(a).toFixed(3)+')');
  ctx.fillStyle=g;const bx=(i+.5)*laneW-laneW*.30;
  ctx.fillRect(bx,hor,laneW*.6,hy-hor);}
 // مسیر پرسپکتیو: سایه‌روشن لاین‌ها (ذوزنقه از افق تا خط خطر)
 for(let i=0;i<4;i+=2){ctx.fillStyle='rgba(0,229,255,.035)';
  ctx.beginPath();ctx.moveTo(xAt(i*laneW,1/R),hor);ctx.lineTo(xAt((i+1)*laneW,1/R),hor);
  ctx.lineTo((i+1)*laneW,hy);ctx.lineTo(i*laneW,hy);ctx.closePath();ctx.fill();}
 // خطوط لاین — همگرا به نقطهٔ محو
 ctx.strokeStyle='rgba(0,229,255,.12)';ctx.lineWidth=2;
 for(let i=1;i<4;i++){ctx.beginPath();ctx.moveTo(xAt(i*laneW,1/R),hor);ctx.lineTo(i*laneW,hy);ctx.stroke();}
 // لبه‌های مسیر
 ctx.strokeStyle='rgba(0,229,255,.2)';ctx.lineWidth=2;
 ctx.beginPath();ctx.moveTo(vpx-vpx/R,hor);ctx.lineTo(0,hy);
 ctx.moveTo(vpx+vpx/R,hor);ctx.lineTo(W,hy);ctx.stroke();
 // گرید ضرب‌ها — ردیف‌ها از عمق به سمت بازیکن می‌شتابند (هم‌راستا با کاشی‌ها)
 if(song.length&&curTravel>0){const spb=curSpb||.6;
  const first=Math.ceil(Math.max(0,songT)/spb)*spb;
  ctx.strokeStyle='#7ef3ff';ctx.lineWidth=1.5;
  for(let bt=first;bt<=songT+curTravel;bt+=spb){const dtt=bt-songT;
   if(dtt<0)continue;const p=dtt/curTravel,s=1/(R-(R-1)*p),yy=hor+(hy-hor)*s;
   ctx.globalAlpha=Math.min(.16,.05+.11*s);
   ctx.beginPath();ctx.moveTo(vpx*(1-s),yy);ctx.lineTo(vpx*(1+s),yy);ctx.stroke();}
  ctx.globalAlpha=1;}
 const dg=ctx.createLinearGradient(0,hy,0,H);dg.addColorStop(0,'rgba(255,43,110,.24)');dg.addColorStop(1,'rgba(255,43,110,.04)');
 ctx.fillStyle=dg;ctx.fillRect(0,hy,W,H-hy);
 ctx.save();ctx.beginPath();ctx.rect(0,hy,W,H-hy);ctx.clip();
 ctx.globalAlpha=.12;ctx.strokeStyle='#ff3b7c';ctx.lineWidth=9;
 const step=34,off=(t*46)%step;
 for(let x=-W*.3;x<W+W*.3;x+=step){ctx.beginPath();ctx.moveTo(x+off,hy);ctx.lineTo(x+off-(H-hy),H);ctx.stroke();}
 ctx.restore();ctx.globalAlpha=1;
 ctx.save();ctx.shadowColor='#ff2bd6';ctx.shadowBlur=16;
 ctx.strokeStyle='rgba(255,43,214,.75)';ctx.lineWidth=3.5;
 ctx.beginPath();ctx.moveTo(0,hy);ctx.lineTo(W,hy);ctx.stroke();ctx.restore();
 for(let i=0;i<4;i++){const cx=(i+.5)*laneW,cy=hy-16-5*Math.sin(t*4+i*1.4);
  ctx.fillStyle='rgba(255,43,214,.55)';
  ctx.beginPath();ctx.moveTo(cx-8,cy-9);ctx.lineTo(cx+8,cy-9);ctx.lineTo(cx,cy+3);ctx.closePath();ctx.fill();}
 for(let i=0;i<4;i++)if(laneFlash[i]>0){
  const g=ctx.createLinearGradient(0,hy-tileSide*2,0,hy);
  g.addColorStop(0,'rgba(255,59,92,0)');g.addColorStop(1,'rgba(255,59,92,'+(.45*laneFlash[i]).toFixed(3)+')');
  ctx.fillStyle=g;ctx.fillRect(i*laneW,hy-tileSide*2,laneW,tileSide*2);}
 // کاشی‌ها — با مقیاس پرسپکتیو (در خط خطر سایز کامل)
 for(const tl of tiles){const sz=tileSide*(tl.ss||1);
  ctx.save();ctx.translate(tlX(tl),tl.sy!==undefined?tl.sy:hor);
  ctx.rotate(Math.sin(t*2.2+tl.wob)*.05);
  ctx.drawImage(TILE_SPR[tl.gold?1:0],-sz*.55,-sz*.55,sz*1.1,sz*1.1);
  ctx.restore();}}
function render(t){ctx.save();
 if(shake>.3)ctx.translate(rnd(-1,1)*shake,rnd(-1,1)*shake);
 ctx.drawImage(bgCache,0,0,W,H);
 drawTwks(t);drawRibbons(t);drawBGFx(t);
 // پالس ضرب روی افق — محیط با ضرب آهنگ نفس می‌کشد (نسخهٔ ۲.۲)
 let beat=0;
 if(state==='playing'&&curSpb>0){const ph=((songT%curSpb)+curSpb)%curSpb/curSpb;beat=1-ph;}
 const glow=Math.max(bgPulse,beat*.55);
 if(glow>.02){ctx.save();ctx.globalCompositeOperation='lighter';
  const g=ctx.createRadialGradient(W/2,horizonY,0,W/2,horizonY,W*(.42+.22*glow));
  g.addColorStop(0,'rgba(0,229,255,'+(.10*glow).toFixed(3)+')');g.addColorStop(1,'rgba(0,229,255,0)');
  ctx.fillStyle=g;ctx.fillRect(0,horizonY-W*.4,W,W*.8);ctx.restore();}
 ctx.strokeStyle='rgba(0,229,255,'+(.22+.14*Math.sin(t*2)+.3*glow).toFixed(3)+')';ctx.lineWidth=2;
 ctx.beginPath();ctx.moveTo(0,horizonY);ctx.lineTo(W,horizonY);ctx.stroke();
 // هالهٔ کمبو در لبه‌ها — هرچه کمبو بالاتر، صفحه داغ‌تر
 if(mult>1&&(state==='playing'||state==='paused')){const ca=Math.min(1,comboT/2.4)*(.05+.025*mult);
  const lg=ctx.createLinearGradient(0,0,W,0);
  lg.addColorStop(0,'rgba(255,43,214,'+ca.toFixed(3)+')');lg.addColorStop(.18,'rgba(255,43,214,0)');
  lg.addColorStop(.82,'rgba(255,43,214,0)');lg.addColorStop(1,'rgba(255,43,214,'+ca.toFixed(3)+')');
  ctx.fillStyle=lg;ctx.fillRect(0,0,W,H);}
 drawTracers();
 drawTilesAll(t);
 drawParts();
 if(state==='playing'||state==='paused'||state==='fail'){drawGun(t);drawTexts();drawCross();}
 if(dmgFlash>0){const g=ctx.createRadialGradient(W/2,H/2,Math.min(W,H)*.25,W/2,H/2,Math.max(W,H)*.75);
  g.addColorStop(0,'rgba(255,40,80,0)');g.addColorStop(1,'rgba(255,40,80,'+(.5*dmgFlash)+')');
  ctx.fillStyle=g;ctx.fillRect(0,0,W,H);}
 ctx.restore();}

// ================= flow =================
function hideOv(){['menu','pauseOv','sndOv','resOv','loadOv','modeOv','aboutOv','lvlOv'].forEach(i=>$(i).classList.add('hidden'));}
// نسخهٔ ۲.۳: یک خطا → فلاش قرمز → شروع خودکار از اول همان بخش (یا موج ۱ در حالت آزاد)
function failRestart(){if(state!=='playing')return;
 state='fail';isDown=false;
 if(MODE==='free'){best=Math.max(best,score);
  try{localStorage.setItem('ns_best',String(best))}catch(e){}}
 showBanner('خطا! — شروع از اول','#ff3b5c');
 setTimeout(()=>{if(state!=='fail')return;
  if(MODE==='camp')startLevel(CAMP.lvl);else startFree();},1250);}
function startLevel(i){CAMP.lvl=i;const L=LEVELS[i];
 CAMP.total=0;CAMP.hits=0;CAMP.missed=0;
 MODE='camp';buildSong(L,L.n,1);
 initBGFX(L.theme);score=0;kills=0;waveN=i+1;shots=0;
 combo=0;comboT=0;mult=1;parts=[];tracers=[];texts=[];tiles=[];laneFlash=[0,0,0,0];
 shake=0;dmgFlash=0;flashT=0;spread=0;lastShot=0;isDown=false;
 state='playing';hideOv();
 $('hud').classList.remove('hidden');
 $('waveLbl').textContent='بخش';
 pauseMusic();snd.ui.play();
 showBanner('بخش '+toFa(L.part)+' از '+toFa(L.partN)+' — '+L.title+' ('+L.comp+')');updHUD();}
function startFree(){MODE='free';
 FREE={wave:0,hits:0,missed:0};
 score=0;kills=0;shots=0;combo=0;comboT=0;mult=1;
 parts=[];tracers=[];texts=[];tiles=[];laneFlash=[0,0,0,0];
 shake=0;dmgFlash=0;flashT=0;spread=0;lastShot=0;isDown=false;
 state='playing';hideOv();
 $('hud').classList.remove('hidden');
 $('waveLbl').textContent='موج';
 pauseMusic();snd.ui.play();
 nextWave(true);}
function nextWave(first){FREE.wave++;waveN=FREE.wave;
 const L=LEVELS[(FREE.wave-1)%LEVELS.length];
 // نسخهٔ ۲.۳ (درخواست کاربر): آزاد = هرچه بالاتر بری سرعت و تعداد کاشی‌ها بیشتر
 const bpmM=Math.min(2,1+(FREE.wave-1)*.07);
 const cnt=Math.min(40,12+FREE.wave*3);
 buildSong(L,cnt,bpmM);
 initBGFX(L.theme);laneFlash=[0,0,0,0];
 showBanner('موج '+toFa(FREE.wave)+' — '+L.title);snd.wave.play();updHUD();}
function campDone(){state='over';isDown=false;snd.ui.play();
 // تکمیل بخش همیشه بی‌خطاست (یک خطا = شروع از اول)؛ ستاره با میانگین کمبو، ویژه با دقت شلیک
 const avg=CAMP.total?score/(CAMP.total*10):0;
 const st=avg>=3?3:avg>=1.9?2:1;
 const spec=shots>0&&CAMP.hits/Math.max(1,shots)>=.85;
 if(st>campProg.stars[CAMP.lvl])campProg.stars[CAMP.lvl]=st;
 if(spec)campProg.spec[CAMP.lvl]=1;
 try{localStorage.setItem('ns_camp23',JSON.stringify(campProg))}catch(e){}
 showResult(true,st,spec,CAMP.hits/Math.max(1,shots));}
function togglePause(){if(state==='playing'){state='paused';$('pauseOv').classList.remove('hidden');}
 else if(state==='paused'){state='playing';$('pauseOv').classList.add('hidden');}}
function toMenu(){state='menu';isDown=false;
 hideOv();$('menu').classList.remove('hidden');
 if(typeof renderPartGrid==='function')renderPartGrid();resumeMusic();}

// ================= events =================
function evPt(e){return rot?{x:e.clientY,y:window.innerWidth-e.clientX}:{x:e.clientX,y:e.clientY};}
window.addEventListener('pointermove',e=>{const p=evPt(e);aimX=p.x;aimY=p.y;});
cv.addEventListener('pointerdown',e=>{const p=evPt(e);aimX=p.x;aimY=p.y;if(state==='playing')isDown=true;});
window.addEventListener('pointerdown',()=>{ensureAC();loadAll();resumeMusic();});
window.addEventListener('pointerup',()=>isDown=false);
window.addEventListener('pointercancel',()=>isDown=false);
window.addEventListener('contextmenu',e=>e.preventDefault());
window.addEventListener('keydown',e=>{
 ensureAC();loadAll();resumeMusic();
 if(e.code==='KeyP'||e.code==='Escape'){if(state==='playing'||state==='paused')togglePause();}
 else if(e.code==='KeyM')setMute(!muted);});
document.addEventListener('visibilitychange',()=>{if(document.hidden&&state==='playing')togglePause();
 if(document.hidden)music.pause();else setTimeout(resumeMusic,300);});

// ================= hooks (QA / دیباگ) =================
window.NS={auto:false,
 get state(){return state},MODE:()=>MODE,
 tiles:()=>tiles.length,score:()=>score,best:()=>best,shots:()=>shots,
 CAMP:()=>CAMP,campProg:()=>campProg,pianoN:()=>Object.keys(PIANO).length,
 loaded:()=>[loadN,loadTotal],vols:()=>({VOL,musicPlaying:!music.paused,musicT:music.currentTime}),
 startLevel:i=>startLevel(i),startFree:()=>startFree(),toMenu:()=>toMenu(),pause:()=>togglePause(),
 setHp:()=>{}, // جان حذف شد (۲.۳) — هوک قدیمی برای سازگاری
 restart:()=>failRestart(),
 fire:(x,y)=>{aimX=x;aimY=y;shoot(performance.now()/1000);},
 aimAt:(x,y)=>{aimX=x;aimY=y;},
 fov:()=>fovRows,setFov:v=>applyFov(v),
 killLine:()=>killLine(),tileInfo:()=>tiles.map(t=>({lane:t.lane,y:Math.round(t.sy||0),s:+(t.ss||1).toFixed(2),note:t.note})),
 skip:()=>{evI=song.length;for(const tl of tiles)tl.a=curTravel+.1;}};

// ================= init =================
resize();aimX=W/2;aimY=H*.4;gunX=W/2;gunY=H+280;
music.play().catch(()=>{});
function frame(ts){const t=ts/1000;const dt=Math.min(.05,(t-lastT)||.016);lastT=t;
 updBGFx(dt);
 if(state==='playing')update(dt,t);
 render(t);requestAnimationFrame(frame);}
requestAnimationFrame(frame);
