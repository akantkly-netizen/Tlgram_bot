'use strict';
// ================= HUD =================
function updHUD(){$('scoreEl').textContent=toFa(score);
 if(MODE==='camp'){const L=LEVELS[CAMP.lvl];
  $('waveEl').textContent=toFa(L.part)+'/'+toFa(L.partN);
  $('progLbl').textContent='کاشی';
  $('progEl').textContent=toFa(CAMP.hits)+' از '+toFa(CAMP.total);}
 else{$('waveEl').textContent=toFa(Math.max(1,waveN));
  $('progLbl').textContent='سرعت';
  $('progEl').textContent='×'+toFa(Math.min(2,1+(FREE.wave-1)*.07).toFixed(2)).replace('.','٫');}
 $('comboEl').textContent='×'+toFa(mult);
 $('comboBox').classList.toggle('hot',mult>1);}
function showBanner(t,c){const b=$('banner');b.textContent=t;
 b.style.color=c||'';b.style.textShadow=c?('0 0 30px '+c+',0 4px 18px rgba(0,0,0,.6)'):'';
 b.classList.remove('show');void b.offsetWidth;b.classList.add('show');}

// ================= انتخاب مرحله (نسخهٔ ۲.۳: آهنگ‌ها بخش‌بخش) =================
function lvlUnlocked(i){return i===0||campProg.stars[i-1]>0}
function renderPartGrid(){const g=$('partGrid');if(!g)return;g.innerHTML='';
 let row=null,cur=null;
 LEVELS.forEach((L,i)=>{
  if(L.title!==cur){cur=L.title;
   const h=document.createElement('div');h.className='songHdr';
   h.innerHTML='<span class="sn">'+L.title+'</span><span class="sc">'+L.comp+'</span>';
   g.appendChild(h);
   row=document.createElement('div');row.className='partRow';g.appendChild(row);}
  const b=document.createElement('button');
  const un=lvlUnlocked(i);
  b.className='partBtn'+(un?'':' locked')+(campProg.stars[i]>0?' done':'');
  b.innerHTML='<span class="pn">بخش '+toFa(L.part)+'</span>'+
   '<span class="stars">'+'★'.repeat(campProg.stars[i])+'☆'.repeat(3-campProg.stars[i])+'</span>'+
   (un?'':'<span class="lock">🔒</span>');
  if(un)b.addEventListener('click',()=>{snd.ui.play();withLoading(()=>startLevel(i))});
  row.appendChild(b);});}

function showResult(win,st,spec,acc){
 $('hud').classList.add('hidden');
 const last=CAMP.lvl+1>=LEVELS.length;
 const T=$('resTitle');T.textContent=last?'همهٔ آهنگ‌ها تمام شد!':'بخش تمام شد!';
 T.classList.toggle('fail',!win);
 const sp=$('starsRow').children;
 for(let k=0;k<3;k++){sp[k].classList.toggle('on',win&&k<st);}
 $('specStar').classList.toggle('hidden',!(win&&spec));
 $('specStar').textContent='★ ویژه — تیرانداز دقیق';
 $('resStats').textContent='دقت شلیک: '+toFa(Math.round(acc*100))+'٪ — امتیاز: '+toFa(score);
 $('nextBtn').style.display=(win&&!last)?'':'none';
 $('resOv').classList.remove('hidden');}

// ================= پنل تنظیمات صدا =================
const VOL_KEYS=[['volMusic','music'],['volShot','shot'],['volPiano','piano'],['volSfx','sfx']];
function volSync(){for(const[id,k]of VOL_KEYS){const v=Math.round(VOL[k]*100);
 $(id).value=v;$(id+'V').textContent=toFa(v)+'٪';}}
function wireVols(){for(const[id,k]of VOL_KEYS){
 $(id).addEventListener('input',()=>{VOL[k]=+$(id).value/100;applyVols();saveVols();
  $(id+'V').textContent=toFa(+$(id).value)+'٪';});
 $(id).addEventListener('change',()=>snd.ui.play());}}

// ================= loading =================
function withLoading(then){ensureAC();loadAll();
 hideOv();$('loadOv').classList.remove('hidden');
 const t0=performance.now();
 const poll=setInterval(()=>{
  const tot=Math.max(1,loadTotal),p=Math.round(loadN/tot*100);
  $('loadBar').style.width=p+'%';$('loadPct').textContent=toFa(p)+'٪';
  const done=loadTotal>0&&loadN>=loadTotal;
  if((done||performance.now()-t0>12000)&&performance.now()-t0>1200){clearInterval(poll);
   $('loadOv').classList.add('hidden');$('loadBar').style.width='0%';then();}},100);}

// ================= wiring =================
$('resumeBtn').addEventListener('click',togglePause);
$('quitBtn').addEventListener('click',toMenu);
$('retryBtn').addEventListener('click',()=>{snd.ui.play();withLoading(()=>startLevel(CAMP.lvl))});
$('nextBtn').addEventListener('click',()=>{snd.ui.play();withLoading(()=>startLevel(CAMP.lvl+1))});
$('resMenuBtn').addEventListener('click',toMenu);
$('muteBtn').addEventListener('click',()=>setMute(!muted));
// منوی اصلی: شروع → انتخاب نوع بازی | توضیحات → اعتبار و مجوزها | آیکن صدا → تنظیمات
$('startBtn').addEventListener('click',()=>{snd.ui.play();
 $('menu').classList.add('hidden');$('modeOv').classList.remove('hidden');});
$('modeLvlBtn').addEventListener('click',()=>{snd.ui.play();renderPartGrid();
 $('modeOv').classList.add('hidden');$('lvlOv').classList.remove('hidden');});
$('modeFreeBtn').addEventListener('click',()=>{snd.ui.play();withLoading(startFree)});
$('modeBackBtn').addEventListener('click',()=>{snd.ui.play();
 $('modeOv').classList.add('hidden');$('menu').classList.remove('hidden');});
$('lvlBackBtn').addEventListener('click',()=>{snd.ui.play();
 $('lvlOv').classList.add('hidden');$('modeOv').classList.remove('hidden');});
$('aboutBtn').addEventListener('click',()=>{snd.ui.play();
 $('menu').classList.add('hidden');$('aboutOv').classList.remove('hidden');});
$('aboutBackBtn').addEventListener('click',()=>{snd.ui.play();
 $('aboutOv').classList.add('hidden');$('menu').classList.remove('hidden');});
$('gearBtn').addEventListener('click',()=>{volSync();snd.ui.play();
 $('menu').classList.add('hidden');$('sndOv').classList.remove('hidden');});
$('sndBackBtn').addEventListener('click',()=>{snd.ui.play();
 $('sndOv').classList.add('hidden');$('menu').classList.remove('hidden');});
wireVols();
$('muteBtn').textContent='صدا: '+(muted?'خاموش':'روشن');
// نسخهٔ ۲.۳: آهنگ‌ها بخش‌بخش + یک خطا = شروع از اول + منوی شروع/توضیحات
