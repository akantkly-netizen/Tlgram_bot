'use strict';
// ================= state =================
let state='menu'; // menu | playing | paused | fail | over
let MODE='camp';  // camp | free
let score=0,best=0,kills=0,waveN=0,shots=0;
let combo=0,comboT=0,mult=1;
let parts=[],tracers=[],texts=[];
let shake=0,dmgFlash=0,flashT=0,spread=0,lastShot=0;
let aimX=0,aimY=0,isDown=false,gunAng=-1.4,recoil=0,gunX=0,gunY=0,mzX=0,mzY=0;
let overTile=false,lastT=0;
let tiles=[],tileSide=90,laneFlash=[0,0,0,0];
const tlXf=tl=>(tl.lane+.5)*W/4;
const tlX=tl=>tl.sx!==undefined?tl.sx:tlXf(tl);
const killLine=()=>H-clamp(H*.13,96,150);
let CAMP={lvl:0,total:0,hits:0,missed:0};
let FREE={wave:0,hits:0,missed:0};
// نسخهٔ ۲.۳: آهنگ‌ها بخش‌بخش شدند — تعداد مراحل داینامیک (طول LEVELS) و کلید پیشرفت جدید
let campProg={stars:LEVELS.map(()=>0),spec:LEVELS.map(()=>0)};
try{const s=JSON.parse(localStorage.getItem('ns_camp23')||'null');
 if(s&&s.stars&&s.stars.length===LEVELS.length&&s.spec)campProg=s;}catch(e){}
try{best=+localStorage.getItem('ns_best')||0}catch(e){}

// ================= song builder: کاشی‌ها = نت‌های آهنگ =================
let song=[],evI=0,songT=0,curTravel=2,curSpb=.6;
// FOV دوربین: ثابت روی ۷ ردیف — اسلایدر FOV حذف شد (نسخهٔ ۲.۱)؛ سایز کاشی در خط خطر همیشه ثابت
let fovRows=7;
const camR=()=>1.6+(fovRows-3)*1.6; // نسبت عمق دور/نزدیک — پرسپکتیو واقعی دوربین
function applyFov(v){fovRows=clamp(Math.round(v*10)/10,3,7.5);
 if(curSpb>0)curTravel=clamp(curSpb*fovRows,1,6);return fovRows;}
// نسخهٔ ۲.۲: لاین کاشی‌ها رندوم شد (درخواست کاربر) — زمان‌بندی و نُت‌ها همچنان نت‌به‌نتِ آهنگ واقعی
// قانون ضدتکرار: هیچ لاینی ۳ بار پشت‌سرهم نمی‌آید تا هدف‌گیری معنا داشته باشد
function randLane(last,prev){let ln=Math.floor(Math.random()*4);
 if(ln===last&&ln===prev)ln=(ln+1+Math.floor(Math.random()*3))%4;
 return ln;}
function buildSong(L,count,bpmM){
 const spb=60/(L.bpm*(bpmM||1));
 const ev=[];let u=0,i=0,last=-1,prev=-1;
 while(ev.length<count){const[n,d]=L.mel[i%L.mel.length];i++;
  if(n>0){const ln=randLane(last,prev);prev=last;last=ln;
   ev.push({t:u*spb,note:n,lane:ln,gold:Math.random()<(L.gold||0)});}
  u+=d;}
 song=ev;evI=0;songT=-.7;curSpb=spb;
 // دوربین: بازهٔ دید ثابت = ۷ ردیف جلوتر — سایز کاشی‌ها/مپ ثابت
 curTravel=clamp(spb*fovRows,1,6);}
function songTitle(){const L=LEVELS[MODE==='camp'?CAMP.lvl:(FREE.wave-1)%LEVELS.length];return L.title;}

// ================= canvas =================
const cv=$('cv'),ctx=cv.getContext('2d');
let W=0,H=0,DPR=1,horizonY=0,bgCache=null,rot=false;
// اندازهٔ واقعی قابل‌مشاهدهٔ صفحه — مقاوم به باگ WebViewهای قدیمی:
// مرجع = clientWidth/Height (layout viewport واقعی)؛ visualViewport فقط وقتی پذیرفته
// می‌شود که از layout بزرگ‌تر نشود (بعضی دستگاه‌ها ~۲برابر/پیکسل فیزیکی گزارش می‌کنند)
function vpSize(){
 const de=document.documentElement;
 let w=de.clientWidth||window.innerWidth||0;
 let h=de.clientHeight||window.innerHeight||0;
 const vv=window.visualViewport;
 if(vv&&vv.width>0){
  if(vv.width<=w+40)w=Math.min(w,vv.width);
  if(vv.height<=h+160)h=Math.min(h,vv.height);}
 if(!(w>100))w=window.innerWidth||360;
 if(!(h>100))h=window.innerHeight||640;
 return{w:Math.round(w),h:Math.round(h)};}
function resize(){const p=vpSize();rot=p.w>p.h;
 const st=$('stage');st.classList.toggle('rot',rot);
 // همیشه سایز صریح پیکسلی — صفحه دقیقاً فِیت گوشی می‌شود (حتی بدون پشتیبانی inset)
 const sw=rot?p.h:p.w,sh=rot?p.w:p.h;
 st.style.width=sw+'px';st.style.height=sh+'px';
 cv.style.width=sw+'px';cv.style.height=sh+'px';
 DPR=Math.min(1.5,window.devicePixelRatio||1);
 W=sw;H=sh;
 cv.width=Math.round(W*DPR);cv.height=Math.round(H*DPR);ctx.setTransform(DPR,0,0,DPR,0,0);
 aimX=clamp(aimX,0,W);aimY=clamp(aimY,0,H);
 horizonY=H*.36;tileSide=Math.min(W/4*.94,H*.13);initBGFX(curTh);}
window.addEventListener('resize',resize);
window.addEventListener('orientationchange',()=>{setTimeout(resize,120);setTimeout(resize,380);});
if(window.visualViewport&&window.visualViewport.addEventListener)
 window.visualViewport.addEventListener('resize',resize);

// ================= sprites =================
function mkCanvas(w,h){const c=document.createElement('canvas');c.width=w;c.height=h||w;return c;}
function rr(g,x,y,w,h,r){if(g.roundRect)g.roundRect(x,y,w,h,r);else g.rect(x,y,w,h);}
function spriteGun(){const w=520,h=150,c=mkCanvas(w,h),g=c.getContext('2d');
 g.fillStyle='#0d1626';g.strokeStyle='#2f4b7a';g.lineWidth=3;
 g.beginPath();rr(g,8,62,60,46,8);g.fill();g.stroke();
 g.beginPath();rr(g,60,58,330,54,10);g.fill();g.stroke();
 g.fillStyle='#132039';g.beginPath();rr(g,380,70,120,26,6);g.fill();g.stroke();
 g.fillStyle='#0a1322';g.fillRect(470,64,26,38);
 g.fillStyle='#1b2c4d';for(let x=90;x<360;x+=34)g.fillRect(x,50,20,10);
 g.fillStyle='#00e5ff';g.shadowColor='#00e5ff';g.shadowBlur=14;g.fillRect(150,66,60,38);
 g.fillStyle='#ff2bd6';g.shadowColor='#ff2bd6';g.fillRect(240,70,34,30);g.shadowBlur=0;
 g.fillStyle='#0d1626';g.strokeStyle='#2f4b7a';
 g.beginPath();rr(g,90,108,44,70,8);g.fill();g.stroke();
 g.beginPath();rr(g,200,110,40,84,8);g.fill();g.stroke();
 g.fillStyle='#1b2c4d';for(let y=120;y<190;y+=14)g.fillRect(204,y,32,6);
 return c;}
const GUN=spriteGun();
function spriteTile(gold){const S=180,c=mkCanvas(S),g=c.getContext('2d');
 const col=gold?'#ffd166':'#00e5ff';
 const gr=g.createLinearGradient(0,0,0,S);
 if(gold){gr.addColorStop(0,'#fff3c9');gr.addColorStop(.45,'#ffc94d');gr.addColorStop(1,'#7a4d00');}
 else{gr.addColorStop(0,'#c9f7ff');gr.addColorStop(.45,'#00c2e8');gr.addColorStop(1,'#045d78');}
 g.shadowColor=col;g.shadowBlur=13;
 g.fillStyle=gr;g.beginPath();rr(g,10,10,S-20,S-20,18);g.fill();g.shadowBlur=0;
 g.strokeStyle='rgba(255,255,255,.7)';g.lineWidth=4;g.beginPath();rr(g,18,18,S-36,S-36,12);g.stroke();
 g.fillStyle='rgba(2,10,22,.8)';g.strokeStyle='rgba(2,10,22,.8)';
 g.beginPath();g.ellipse(S*.42,S*.66,S*.115,S*.085,-.28,0,TAU);g.fill();
 g.lineWidth=8;g.beginPath();g.moveTo(S*.515,S*.63);g.lineTo(S*.515,S*.26);g.stroke();
 g.lineWidth=6;g.beginPath();g.moveTo(S*.515,S*.26);g.quadraticCurveTo(S*.68,S*.28,S*.66,S*.42);g.stroke();
 return c;}
const TILE_SPR=[spriteTile(false),spriteTile(true)];

// ================= tiles =================
function spawnTile(ev){tiles.push({lane:ev.lane,a:0,note:ev.note,gold:ev.gold,wob:rnd(0,TAU)});
 if(MODE==='camp')CAMP.total++;else FREE.total++;}
// نسخهٔ ۲.۳ (درخواست کاربر): یک خطا = بازی از اول — جان/HP حذف شد
function missTile(tl,hy){if(MODE==='camp')CAMP.missed++;else FREE.missed++;
 dmgFlash=1;shake=Math.min(14,shake+6);laneFlash[tl.lane]=1;
 combo=0;mult=1;
 addText(tlX(tl),hy-40,'خطا!','#ff3b5c',20);
 boomFX(tlX(tl),hy,'#ff3b5c',16);snd.boom.play(.55);
 failRestart();}
function hitTile(i){const tl=tiles[i];tiles.splice(i,1);
 if(MODE==='camp')CAMP.hits++;else FREE.hits++;
 const pts=(tl.gold?50:10)*mult;score+=pts;kills++;
 playNote(tl.note);pulseBG();
 noteFX(tlX(tl),tl.sy,tl.gold?'#ffd166':'#00e5ff');
 boomFX(tlX(tl),tl.sy,tl.gold?'#ffd166':'#00e5ff',tileSide*(tl.ss||1)*.42);
 addText(tlX(tl),tl.sy,'+'+toFa(pts),tl.gold?'#ffd166':'#7ef3ff',19);
 combo++;comboT=2.4;mult=1+Math.min(4,Math.floor(combo/4));
 if(mult>1&&combo%5===0)showStreak();}
function segDist(x1,y1,x2,y2,px,py){const dx=x2-x1,dy=y2-y1,L2=dx*dx+dy*dy||1;
 let t=((px-x1)*dx+(py-y1)*dy)/L2;t=clamp(t,0,1);
 return Math.hypot(px-(x1+dx*t),py-(y1+dy*t));}

// ================= shooting: دقیق، بدون پراکندگی روی هدف‌گیری =================
function shoot(t){if(t-lastShot<1/9)return;lastShot=t;shots++;
 spread=Math.min(1,spread+.16);recoil=Math.min(1,recoil+.55);flashT=.06;
 snd.shoot.play(rnd(.92,1.1));
 let hit=-1,hd=1e9;
 for(let i=0;i<tiles.length;i++){const tl=tiles[i],tol=tileSide*(tl.ss||1)*.62;
  const dx=Math.abs(aimX-tlX(tl)),dy=Math.abs(aimY-(tl.sy||0));
  if(dx<=tol&&dy<=tol){const d=dx*dx+dy*dy;if(d<hd){hd=d;hit=i;}}}
 if(hit<0)for(let i=0;i<tiles.length;i++){const tl=tiles[i],tol=tileSide*(tl.ss||1)*.55;
  if(segDist(mzX,mzY,aimX,aimY,tlX(tl),tl.sy||0)<=tol){
   const d=Math.abs(aimX-tlX(tl))+Math.abs(aimY-(tl.sy||0));
   if(d<hd){hd=d;hit=i;}}}
 tracers.push({x1:mzX,y1:mzY,x2:aimX+rnd(-3,3),y2:aimY+rnd(-3,3),life:.06});
 parts.push({x:mzX,y:mzY-16,vx:rnd(-150,150),vy:rnd(-280,-140),life:.55,ml:.55,sz:4,c:'#ffd166',g:720});
 shake=Math.min(10,shake+1.2);
 if(hit>=0)hitTile(hit);else snd.pop.play(.8);}

// ================= FX =================
function sparks(x,y,c,n){for(let i=0;i<n;i++){const a=rnd(0,TAU),v=rnd(60,300);
 parts.push({x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v,life:rnd(.2,.45),ml:.45,sz:rnd(2,4),c:Math.random()<.4?'#fff':c,g:260});}}
function boomFX(x,y,c,r){
 for(let i=0;i<16;i++){const a=rnd(0,TAU),v=rnd(60,320);
  parts.push({x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v,life:rnd(.3,.7),ml:.7,sz:rnd(2,5),c:Math.random()<.3?'#fff':c,g:220});}
 parts.push({ring:true,x,y,r:6,vr:r*7,life:.35,ml:.35,c:c});
 parts.push({flash:true,x,y,r:Math.max(14,r),life:.12,ml:.12,c:'#fff'});}
// نت‌های موسیقی شناور روی هر ضربه — محیط زنده‌تر (نسخهٔ ۲.۲)
let NOTE_SPR=null;
function spriteNote(){const c=mkCanvas(96),g=c.getContext('2d');
 g.shadowColor='#7ef3ff';g.shadowBlur=10;
 g.fillStyle='#eafcff';
 g.beginPath();g.ellipse(34,72,15,11,-.35,0,TAU);g.fill();
 g.fillRect(46,20,6,52);
 g.beginPath();g.moveTo(46,20);g.quadraticCurveTo(72,26,78,44);
 g.quadraticCurveTo(68,38,52,40);g.lineTo(52,50);g.quadraticCurveTo(70,48,82,54);
 g.quadraticCurveTo(74,28,46,14);g.closePath();g.fill();
 return c;}
function noteFX(x,y,c){if(!NOTE_SPR)NOTE_SPR=spriteNote();
 const n=1+Math.floor(Math.random()*2);
 for(let i=0;i<n;i++)parts.push({note:true,x:x+rnd(-10,10),y,vx:rnd(-46,46),vy:-rnd(60,130),
  life:rnd(.9,1.3),ml:1.3,sz:rnd(17,27),c,rot:rnd(-.5,.5),vr:rnd(-1.6,1.6)});}
const STREAKS=['','عالی!','بی‌نقص!','وحشیانه!','افسانه‌ای!'];
function showStreak(){addText(W/2,H*.3,'کمبو ×'+toFa(mult)+' — '+STREAKS[Math.min(4,mult)],'#ff2bd6',26);}
function addText(x,y,str,c,size){texts.push({x,y,str,c,size,life:.95,ml:.95});}

// ================= gun & update =================
// نسخهٔ ۲.۱: تفنگ دقیقاً وسط (W/2) و محورش ۲۸۰px زیر صفحه — فقط سرِ لوله بیرون می‌ماند تا دید را نگیرد
function updateGun(dt,t){const px=W/2;
 const py=H+280+Math.cos(t*1.7)*3;
 gunX+=(px-gunX)*Math.min(1,dt*10);gunY+=(py-gunY)*Math.min(1,dt*10);
 const target=clamp(Math.atan2(aimY-gunY,aimX-gunX),-1.9,-1.0);
 gunAng+=(target-gunAng)*Math.min(1,dt*14);
 recoil=Math.max(0,recoil-dt*6);}
function update(dt,t){
 updateGun(dt,t);
 flashT=Math.max(0,flashT-dt);
 spread=Math.max(0,spread-dt*1.6);
 dmgFlash=Math.max(0,dmgFlash-dt*2.2);
 shake*=Math.pow(.0008,dt);
 for(let i=0;i<4;i++)laneFlash[i]=Math.max(0,laneFlash[i]-dt*2.2);
 if(comboT>0){comboT-=dt;if(comboT<=0){combo=0;mult=1;}}
 songT+=dt;
 while(evI<song.length&&song[evI].t<=songT){spawnTile(song[evI]);evI++;}
 // حرکت پرسپکتیو: کاشی از افق (کوچک) تا خط خطر (با سایز کامل tileSide) — «دوربین» = R از اسلایدر FOV
 const hy=killLine(),hor=horizonY,R=camR();
 for(let i=tiles.length-1;i>=0;i--){const tl=tiles[i];tl.a+=dt;
  const p=clamp(tl.a/curTravel,0,1),s=1/(R-(R-1)*p);
  tl.ss=s;tl.sx=W/2+(tlXf(tl)-W/2)*s;tl.sy=hor+(hy-hor)*s;
  if(tl.a>=curTravel){tiles.splice(i,1);missTile(tl,hy);if(state!=='playing')return;}}
 if(evI>=song.length&&tiles.length===0){
  if(MODE==='camp')campDone();else nextWave();}
 if(NS.auto&&tiles.length){const tl=tiles[0];aimX=tlX(tl);aimY=tl.sy||0;shoot(t);}
 if(isDown)shoot(t);
 overTile=false;
 for(const tl of tiles){const tol=tileSide*(tl.ss||1)*.62;
  if(Math.abs(aimX-tlX(tl))<=tol&&Math.abs(aimY-(tl.sy||0))<=tol){overTile=true;break;}}
 for(let i=tracers.length-1;i>=0;i--){tracers[i].life-=dt;if(tracers[i].life<=0)tracers.splice(i,1);}
 for(let i=texts.length-1;i>=0;i--){const x=texts[i];x.life-=dt;x.y-=42*dt;if(x.life<=0)texts.splice(i,1);}
 for(let i=parts.length-1;i>=0;i--){const p=parts[i];p.life-=dt;
  if(p.life<=0){parts.splice(i,1);continue;}
  if(p.ring){p.r+=p.vr*dt;continue;}
  if(p.flash)continue;
  if(p.note){p.rot+=p.vr*dt;p.x+=Math.sin(p.life*6)*26*dt;}
  p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=(p.g||0)*dt;}
 updHUD();}
